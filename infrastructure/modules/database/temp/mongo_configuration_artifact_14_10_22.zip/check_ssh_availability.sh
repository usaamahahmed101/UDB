#!/bin/bash
   
declare -a mongo_address=("192.168.1.2")
for i in ${mongo_address[@]};
do
    while true; do
        echo "[ SSH Check Connectivity for ${i} ]"
        ssh -o ProxyCommand="ssh -W %h:%p -q 104.154.196.191" -i ~/.ssh/ansible_ed25519 ansible@${i} 'exit 0;'
        if [ $? == 0 ];then
            echo "SSH Connection to ${i} is possible"
            echo " Current Directory is '`pwd`'"
            ansible-playbook -i infrastructure/modules/database/mongod_artifacts/ansible_inventory.ini --private-key  ~/.ssh/ansible_ed25519 infrastructure/modules/database/ansible_plays/basic_packages.yaml
            break;
        else
            echo "SSH connection to ${i} is not possible"
        sleep 10
        fi
    done
done 


