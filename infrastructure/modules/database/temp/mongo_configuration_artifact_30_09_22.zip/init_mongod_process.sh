#!/bin/bash
initiate_rs="`(/sbin/ip -o -4 addr list eth0 | awk '{print $4}' | cut -d/ -f1)`:27018"

systemctl daemon-reload
systemctl start mongod 

while true; do
    if [[ -f /log/mongodb.log ]]
    then
        break
    else 
        systemctl start mongod
    fi 
    sleep 10
done

if [[ "192.168.1.2:27018" == "$initiate_rs"  ]]
then
    echo "Initialization of the replica set!" 
    /bin/mongosh localhost:27018/local /tmp/repl_init.conf
fi







