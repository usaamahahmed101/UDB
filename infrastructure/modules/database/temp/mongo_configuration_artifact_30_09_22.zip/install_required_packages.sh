#!/bin/bash
echo "Install required Packages"
yum install -y numactl
